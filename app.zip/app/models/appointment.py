# Import Base from app.models
from app.models import Base

# Impot fields from marshmallow
from marshmallow import fields

# Import db
from app import db


class Appointment(Base):
    name = db.Column(db.String(128), nullable=False)
    purpose = db.Column(db.String(128), nullable=False)
    date = db.Column(db.String(128), nullable=False)
    status = db.Column(db.String(128), nullable=False)

    # New Admin
    def __init__(self, name, purpose, date, status):
        self.name = name
        self.purpose = purpose
        self.date = date
        self.status = status
