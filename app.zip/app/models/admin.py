# Import Base from app.models
from app.models import Base

# Impot fields from marshmallow
from marshmallow import fields

# Import db
from app import db

# Import marshmallow
from app import ma


class Admin(Base):
    name = db.Column(db.String(128), nullable=False)
    address = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(128), nullable=False)
    photo = db.Column(db.String(128), nullable=False)
    password = db.Column(db.String(128), nullable=False)

    # New Admin
    def __init__(self, name, address, email, phone, password, photo):
        self.name = name
        self.address = address
        self.email = email
        self.phone = phone
        self.password = password
        self.photo = photo


# Create Admin Schema
class AdminSchema(ma.Schema):
    id = fields.Integer()
    name = fields.String()
    address = fields.String()
    email = fields.String()
    phone = fields.String()
    password = fields.String()
    photo = fields.String()


admin_schema = AdminSchema(strict=True)
admins_schema = AdminSchema(many=True, strict=True)
