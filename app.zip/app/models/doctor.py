# Import Base from app.models
from app.models import Base

# Impot fields from marshmallow
from marshmallow import fields

# Import db
from app import db


class Doctor(Base):
    name = db.Column(db.String(128), nullable=False)
    address = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(128), nullable=False)
    photo = db.Column(db.String(128), nullable=False)
    password = db.Column(db.String(128), nullable=False)

    # New Admin
    def __init__(self, name, address, email, phone, password, photo):
        self.name = name
        self.address = address
        self.email = email
        self.phone = phone
        self.password = password
        self.photo = photo
