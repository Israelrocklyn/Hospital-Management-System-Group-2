from flask import Flask, render_template

# Import SQLAlchemy
from flask_sqlalchemy import SQLAlchemy

# Import Marchmellow
from flask_marshmallow import Marshmallow

app = Flask(__name__)

app.config.from_object('config')

@app.errorhandler(404)
def bar(error):
        return render_template('error.html'), 404

# Init SQLAlchemy
db = SQLAlchemy(app)

# Init Marshmellow
ma = Marshmallow(app)

# Import routes from app.api
from app.controlers import routes

# Set all routes to app
app.register_blueprint(routes)

db.create_all()