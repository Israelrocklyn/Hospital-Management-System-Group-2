from flask import Blueprint

routes = Blueprint('app', __name__, url_prefix='')

from app.controlers import home
from app.controlers import all_doctors
from app.controlers import doctor
from app.controlers import patient
from app.controlers import appointment
from app.controlers import admin