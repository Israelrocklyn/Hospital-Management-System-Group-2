# Import routes from app.api
from app.controlers import routes

# Import router from flask
from flask import request, jsonify, render_template

from app.models.admin import Admin, admins_schema
from app.models.doctor import Doctor
from app.models.patiant import Patiant

# Import db from app
from app import db

from app import app


@routes.route('/admin', methods=['GET'])
def get_admin():
    # admin = Admin.query.filter_by(id=1).first()

    all_admins = Admin.query.all()
    result = admins_schema.dump(all_admins)
    datas = result.data
    return render_template('admin.html',  title="Admin", table="All Admins", user="Admin", datas=datas, admin=None)


@routes.route('/admin-all-doctor', methods=['GET'])
def get_admin_doctor():
    admin = Admin.query.filter_by(id=1).first()

    datas = Doctor.query.all()
    return render_template('admin.html',  title="Admin", table="All Doctors", user="Admin", admin=admin, datas=datas)


@routes.route('/admin-all-patient', methods=['GET'])
def get_admin_patiant():
    admin = Admin.query.filter_by(id=1).first()

    datas = Patiant.query.all()
    return render_template('admin.html',  title="Admin", table="All Patiant", user="Admin", admin=admin, datas=datas)


@routes.route('/new-admin', methods=['POST'])
def create_admin():
    name = request.form['name']
    address = request.form['address']
    email = request.form['email']
    phone = request.form['phone']
    password = request.form['password']

    if request.files:
        photo = request.files['photo']
        photo.save(app.config['IMAGE_UPLOAD'] +
                   '/' + photo.filename)

        new_admin = Admin(name, address, email, phone,
                          password, photo.filename)
        db.session.add(new_admin)
        db.session.commit()

        return 'ok'


@routes.route('/login', methods=['POST'])
def login_admin():
    email = request.form['email']
    password = request.form['password']

    user = Admin.query.filter_by(email=email).first()
    point = 'admin'

    if user == None:
        user = Doctor.query.filter_by(email=email).first()
        point = 'doctor'
        if user == None:
            user = Patiant.query.filter_by(email=email).first()
            point = 'patient'
            
        if user == None:
            return jsonify({
                "message": 'No user exit'
            })

    if user.password == password:
        return jsonify({
            "message": '1560576233',
            "point": point
        })
    else:
        return jsonify({
            "message": 'Incorret password'
        })
