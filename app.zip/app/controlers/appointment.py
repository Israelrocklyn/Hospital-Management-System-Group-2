# Import routes from app.api
from app.controlers import routes

# Import router from flask
from flask import request, jsonify, render_template

from app.models.appointment import Appointment

# Import db from app
from app import db

from app import app


@routes.route('/new-appointment', methods=['POST'])
def create_appointment():
    name = request.form['name']
    purpose = request.form['purpose']
    date = request.form['date']
    status = request.form['status']

    new_appointment = Appointment(name, purpose, date, status)
    db.session.add(new_appointment)
    db.session.commit()

    return 'ok'
