# Import routes from app.api
from app.controlers import routes

# Import router from flask
from flask import request, jsonify, render_template

# # Import School, school_schema, schools_schema from app.models.school
# from app.models.school import School, school_schema, schools_schema

# Import db from app
from app import db


@routes.route('/all-doctors', methods=['GET'])
def all_doctors():
    return render_template('all_doctors.html', title="All Doctors", user="Patient")
