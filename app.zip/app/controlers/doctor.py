# Import routes from app.api
from app.controlers import routes

# Import router from flask
from flask import request, jsonify, render_template

from app.models.doctor import Doctor
from app.models.appointment import Appointment

# Import db from app
from app import db

from app import app


@routes.route('/doctor', methods=['GET'])
def doctor():
    doctor = Doctor.query.filter_by(id=1).first()

    appointments = Appointment.query.all()
    print(appointments[0].purpose)
    return render_template('doctor.html',  title="Doctor", user="Doctor", doctor=doctor, datas=appointments)


@routes.route('/new-doctor', methods=['POST'])
def create_doctor():
    name = request.form['name']
    address = request.form['address']
    email = request.form['email']
    phone = request.form['phone']
    password = request.form['password']

    if request.files:
        photo = request.files['photo']
        photo.save(app.config['IMAGE_UPLOAD'] +
                   '/' + photo.filename)

        new_doctor = Doctor(name, address, email, phone,
                          password, photo.filename)
        db.session.add(new_doctor)
        db.session.commit()

        return 'ok'
