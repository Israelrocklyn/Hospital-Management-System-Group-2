# Import routes from app.api
from app.controlers import routes

# Import router from flask
from flask import request, jsonify, render_template

from app.models.patiant import Patiant
from app.models.appointment import Appointment

# Import db from app
from app import db

from app import app


@routes.route('/patient', methods=['GET'])
def patient():
    all_appointments = Appointment.query.all()
    return render_template('patient.html',  title="Patient", user="Patient", datas=all_appointments)


@routes.route('/new-patient', methods=['POST'])
def create_patient():
    name = request.form['name']
    address = request.form['address']
    email = request.form['email']
    phone = request.form['phone']
    password = request.form['password']

    if request.files:
        photo = request.files['photo']
        photo.save(app.config['IMAGE_UPLOAD'] +
                   '/' + photo.filename)

        new_doctor = Patiant(name, address, email, phone,
                             password, photo.filename)
        db.session.add(new_doctor)
        db.session.commit()

        return 'ok'
